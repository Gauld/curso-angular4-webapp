export var GLOBAL = {
	url: 'http://localhost/curso-angular4-backend/index.php/',
	header_color: '#E03137'
};